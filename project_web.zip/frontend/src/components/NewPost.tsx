'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

export function NewPost() {
  const [content, setContent] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log('New post:', content)
    setContent('')
  }

  return (
    <form onSubmit={handleSubmit} className="p-4 border-b border-gray-200">
      <Textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Une pensée à partager ?"
        className="w-full p-2 mb-2"
        maxLength={280}
      />
      <div className="flex justify-between items-center">
        <span className="text-sm text-gray-500">{280 - content.length} caractères restants</span>
        <Button type="submit" disabled={content.length === 0}>Poster</Button>
      </div>
    </form>
  )
}
