import React from "react";
import { NewPost } from "../components/NewPost";
import { Post } from "../components/Post";

const posts = [
  { id: 1, author: 'John Doe', content: 'Hello, Twitter clone!', timestamp: '2 hours ago', likes: 5, comments: 2, retweets: 1 },
  { id: 2, author: 'Jane Smith', content: 'React and Next.js are awesome!', timestamp: '4 hours ago', likes: 10, comments: 3, retweets: 2 },
  { id: 3, author: 'Jane Smith', content: 'React and Next.js are awesome!', timestamp: '4 hours ago', likes: 10, comments: 3, retweets: 2 },
  { id: 4, author: 'Jane Smith', content: 'React and Next.js are awesome!', timestamp: '4 hours ago', likes: 10, comments: 3, retweets: 2 },
  { id: 5, author: 'Jane Smith', content: 'React and Next.js are awesome!', timestamp: '4 hours ago', likes: 10, comments: 3, retweets: 2 },
  { id: 6, author: 'Jane Smith', content: 'React and Next.js are awesome!', timestamp: '4 hours ago', likes: 10, comments: 3, retweets: 2 },
]

export const Home = () => {
  return (
    <div className="home-center min-h-screen items-center">
      <div className="max-w-2xl w-full mx-auto bg-white">
        <h1 className="text-xl font-bold p-4 border-b border-gray-200">Fil d'actualité</h1>
        <NewPost />
        <div>
          {posts.map(post => (
            <Post key={post.id} {...post} />
          ))}
        </div>
      </div>
    </div>
  );
};


